angular.module('hotelbooking').controller('reviewCtrl',['$scope', '$http', '$state','doreviewService', function($scope, $http, $state, doreviewService) {
  var selectedHotelreviews = $state.params.selectedHotelreviews;
  $scope.reviewDetails = [];
  doreviewService.reviewService(selectedHotelreviews,function reviewResponse(response) {
      $scope.reviewDetails = response.data;
  })

}]);
