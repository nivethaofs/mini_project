angular.module('hotelbooking').controller('hotelCtrl',['$scope', '$http', '$state','dohotelService', function($scope, $http,$state,dohotelService) {
  var selectedCity = $state.params.selectedCity;
  $scope.hoteldetails=[];
  $scope.imagedetails=[];
  dohotelService.hotelService(selectedCity,function hotelResponse(response) {
      $scope.hoteldetails = response.data;
  }, function imageResponse(response) {
    $scope.imagedetails = response.data;
  });

  $scope.hotelReviews = function hotelReviews(selectedHotelreviews){
      $state.go('root.home.city.reviews',
      {
        selectedHotelreviews : selectedHotelreviews
      });
  }
  $scope.selectroom = function selectroom(selectedHotel) {
    $state.go('root.home.city.hotel.room', {
      selectedHotel : selectedHotel
    });
  }
}]);
