angular.module('hotelbooking').controller('cityCtrl',['$scope', '$http', '$state','docityService', function($scope, $http, $state, docityService) {
  $scope.citydetails = [];
  docityService.cityService(function cityResponse (response) {
    $scope.citydetails = response.data;
  });

  $scope.selectHotel = function selectHotel(selectedCity) {
    $state.go('root.home.city.hotel', {
      selectedCity: selectedCity
    });
  }
  $scope.history = function history() {
    $state.go('root.home.city.historyofbookings');
  }
  $scope.signout = function signout() {
    $state.go('root.login');
    sessionStorage.clear();
  }
}]);
