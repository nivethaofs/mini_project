angular.module('hotelbooking').controller('historyofbookingsCtrl',['$scope', '$http', '$state','dohistoryofbookingService', function($scope, $http, $state, dohistoryofbookingService) {
  $scope.historyDetails = [];
  dohistoryofbookingService.historyofbookingService(function historydetailsResponse(response) {
    $scope.historyDetails = response.data;
    if ($scope.historyDetails == "") {
      console.log("You have not yet booked!!!");
    }
  })
  $scope.cancelBooking = function cancelBooking(bookid) {
    dohistoryofbookingService.cancelbookingService(bookid,function cancelbookingResponse(response) {
      $state.reload();
    })
  }
  $scope.comments = function comments(selectedHotel) {
    sessionStorage.setItem("hotelid", selectedHotel);
    $state.go('root.home.city.comment');
  }
}]);
