angular.module("hotelbooking").controller('dateControl', ['$scope', '$state', function($scope,$state) {
  $scope.datesubmission = function datesubmission(checkin,checkout) {
    sessionStorage.setItem("userCheckin", checkin);
    sessionStorage.setItem("userCheckout", checkout);
    if (checkin && checkout != ""){
        $state.go('root.home.city');
    }else {
      alert ("Please fill the input fields");
    }

}
}]);
