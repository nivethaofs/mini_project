angular.module('hotelbooking').controller('signupControl', ['$scope', '$http', '$state','dosignupService', function($scope, $http, $state, dosignupService) {
  $scope.submit = function(user, email, pwd) {
    var data = {
      name: user,
      email: email,
      pwd: pwd,
      isactive: 1
    };
    dosignupService.signupService(successResponse,failureResponse,data);
  }
  var successResponse = function successResponse (data) {
    $scope.Status = "success";
    $state.go('root.login');
  };
  var failureResponse = function failureResponse (data){
    $scope.Status = "failure";
  };
  $scope.redirectIndex = function() {
    $state.go('root.login');
  }
}]);
