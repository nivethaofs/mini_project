angular.module("hotelbooking").controller('formCtrl', ['$scope', '$http', '$state','loginService', function($scope, $http, $state, loginService) {
  $scope.userDetails = [];
  $scope.welcomeForm = false;
  $scope.loginform = true;
  $scope.maindiv = true;
  $scope.login = function(username, pwd) {
    var data = {
      email: username,
      pwd: pwd
    };
    loginService.loginService(callbackSuccess,callbackFailure,data);
}
    var callbackSuccess = function callbackSuccess(response) {
      if (response.status == 200) {
          $scope.Status = 'Successfully logged in';
          $scope.userDetails = JSON.parse(response.data);
          $scope.userId = $scope.userDetails.uid;
          sessionStorage.setItem("userId", JSON.stringify($scope.userId));
          $scope.loginform = false;
          $scope.maindiv = false;
          $scope.welcomeForm = true;
          alert("Welcome!!");
          $state.go('root.home.date');
        } else {
          $scope.Status = 'Invalid user';
        }
      };
      var callbackFailure = function callbackFailure (response) {
        $scope.Status = 'Invalid user';
      };

}]);
