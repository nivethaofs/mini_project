angular.module('hotelbooking', ["ui.router"])
  .config(function($stateProvider, $urlRouterProvider) {
      $urlRouterProvider.otherwise("/login");

      $stateProvider
          .state('root', {
              abstract: true,
              url:''
          })
          .state('root.login', {
              url: '/login',
              templateUrl: 'views/login.html',
              controller:'formCtrl',
              service : 'loginService'
          })
          .state('root.signup', {
              url: '/signup',
              templateUrl: 'views/signup.html',
              controller:'signupControl',
              service : 'dosignupService'
          })
          .state('root.home', {
              url: '/home',
              templateUrl: 'views/home.html'
          })
          .state('root.home.date', {
              url: '/date',
              templateUrl: 'views/bookingdate.html',
              controller:'dateControl'
          })
          .state('root.home.city', {
            url: '/city',
            templateUrl: 'views/city.html',
            controller:'cityCtrl',
            service:'docityService'
          })
          .state('root.home.city.hotel', {
            url: '/hotel/:selectedCity',
            templateUrl: 'views/hotel.html',
            controller:'hotelCtrl',
            service : 'dohotelService'
          })
          .state('root.home.city.reviews', {
            url: '/reviews/:selectedHotelreviews',
            templateUrl: 'views/review.html',
            controller:'reviewCtrl',
            service : 'doreviewService'
          })
          .state('root.home.city.comment', {
            url: '/comment',
            templateUrl: 'views/comment.html',
            controller:'commentsCtrl',
            service : 'docommentsService'
          })
          .state('root.home.city.historyofbookings', {
            url: '/historyofbookings',
            templateUrl: 'views/historyofbookings.html',
            controller:'historyofbookingsCtrl',
            service : 'dohistoryofbookingService'
          })
          .state('root.home.city.hotel.room', {
            url: '/room/:selectedHotel',
            templateUrl: 'views/room.html',
            controller:'roomCtrl',
            service : 'doroomService'
          });
  });
