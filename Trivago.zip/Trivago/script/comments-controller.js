angular.module('hotelbooking').controller('commentsCtrl',['$scope', '$http', '$state','docommentsService', function($scope, $http,$state, docommentsService) {
  $scope.submit = function submit(rating,comment){
    var hotelid = sessionStorage.getItem("hotelid");
    var userLoginid = sessionStorage.getItem("userId");
    var data = {
      rating : rating,
      feedback : comment,
      user : {
          uid : userLoginid,
      },
      hotel : {
          id :hotelid
      }
    };
    docommentsService.commentsService(rating,comment,data,function commentsResponse (data) {
      $scope.Status = "success";
      alert("Your feedback has been posted...");
      $state.go('root.home.city.historyofbookings');
    })
  }
}]);
