angular.module('hotelbooking').controller('roomCtrl',['$scope', '$http', '$state','doroomService', function($scope, $http, $state, doroomService) {
  var selectedHotel = $state.params.selectedHotel;
  $scope.roomdetails = [];
  doroomService.roomService(selectedHotel,function roomResponse(response) {
    $scope.roomdetails = response.data;
    sessionStorage.setItem("roomId", JSON.stringify($scope.roomdetails));
  })
  $scope.bookroom = function bookroom(selectedRoombooking) {
    var userLoginid = sessionStorage.getItem("userId");
    var checkin = sessionStorage.getItem("userCheckin");
    var checkout = sessionStorage.getItem("userCheckout");
    var data = {
      checkin: checkin,
      checkout: checkout,
      user: {
        uid: userLoginid,
      },
      room: {
        id: selectedRoombooking
      },
      status: "Booked"

    };
    doroomService.bookService(data);
  }
}]);
