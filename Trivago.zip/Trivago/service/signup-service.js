angular.module("hotelbooking").service('dosignupService', ['$http', function($http) {
  this.signupService = function signupService(successResponse,failureResponse,data) {
    var url = "http://localhost:8080/MVP/user/add";
    $http.post(url, data)
    .then(function(data, Status) {
      console.log("Success",data);
      successResponse(data);
    }, function(data, Status) {
      console.log("error");
      failureResponse(data);
    })
  }
}]);
