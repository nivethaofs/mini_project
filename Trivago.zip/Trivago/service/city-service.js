angular.module("hotelbooking").service('docityService', ['$http', function($http) {
  this.cityService = function cityService(cityResponse) {
    var url = "http://localhost:8080/MVP/city/getAllCities";
    $http({
      method: 'GET',
      url: url
    }).then(function successCallback(response) {
      console.log("Success", response);
      cityResponse(response);
    },function errorCallback(response) {
      console.log("Error",response);
    })
  }
}]);
