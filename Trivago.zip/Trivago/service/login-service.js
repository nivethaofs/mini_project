angular.module("hotelbooking").service('loginService', ['$http', function($http) {
  this.loginService = function loginService (callbackSuccess,callbackFailure,data) {
  var url = "http://localhost:8080/MVP/user/auth";
  console.log("##-----url--", url)
  $http.post(url, data)
    .then(function successCallback(response) {
        console.log("login success",response);
        callbackSuccess(response);
      },function errorCallback(response){
          console.log("login failed",response);
          callbackFailure(response);
      })
    }
}]);
