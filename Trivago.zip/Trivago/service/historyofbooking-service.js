angular.module("hotelbooking").service('dohistoryofbookingService', ['$http', function($http) {
  this.historyofbookingService = function historyofbookingService (historyofbookingResponse){
    var userLoginid = sessionStorage.getItem("userId");
    var url = "http://localhost:8080/MVP/book/getAllBookings?userid=" + userLoginid;
    $http({
      method: 'GET',
      url: url
    }).then(function successCallback(response) {
      console.log("Success", response);
      historyofbookingResponse(response);
    }, function errorCallback(response) {
      console.log("error", response);
    })
  }
  this.cancelbookingService = function cancelbookingService(bookid,cancelbookingResponse) {
    var url = "http://localhost:8080/MVP/book/cancel?bookid=" + bookid;
    $http({
      method: 'GET',
      url: url
    }).then(function successCallback(response) {
      console.log("success");
      alert("Your Booking have been cancelled!!");
      cancelbookingResponse(response);
    }, function errorCallback(response) {
      console.log("-------err---", response);
      alert("Error");
    })
  }
}]);
