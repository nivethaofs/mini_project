angular.module("hotelbooking").service('dohotelService', ['$http', function($http) {
 this.hotelService = function hotelService (selectedCity,hotelResponse,imageResponse) {
   var url="http://localhost:8080/MVP/hotel/getAllHotels?cityid="+selectedCity;
   $http({
     method: 'GET',
     url: url
   }).then(function successCallback(response) {
     console.log("success",response);
     hotelResponse(response);
   },function errorCallback(response) {
     console.log("error",response);
   })
   var url="http://localhost:8080/MVP/image/getAllImages?cityid="+selectedCity;
   $http({
     method: 'GET',
     url: url
   }).then(function successCallback(response) {
     console.log("success",response);
     imageResponse(response);
   }, function errorCallback(response) {
     console.log("error",response);
   })
 }
}]);
