angular.module("hotelbooking").service('docommentsService', ['$http', function($http) {
  this.commentsService = function commentsService (rating,comment,data,commentsResponse) {
    var url="http://localhost:8080/MVP/review/add";
    $http.post(url, data)
    .then(function (data,Status) {
      console.log("success");
      commentsResponse(data);
    },function (data,Status) {
      console.log("Error");
    })
  }
}]);
