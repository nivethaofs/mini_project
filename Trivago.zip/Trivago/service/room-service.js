angular.module("hotelbooking").service('doroomService', ['$http', function($http) {
  this.roomService = function roomService (selectedHotel,hotelResponse) {
  var url = "http://localhost:8080/MVP/room/getAllRooms?hotelid=" + selectedHotel;
  $http({
    method: 'GET',
    url: url
  }).then(function successCallback(response) {
    console.log("success", response);
    hotelResponse(response);
  }, function errorCallback(response) {
    console.log("error", response);
  })
}
this.bookService = function bookService (data) {
var url = "http://localhost:8080/MVP/book/add";
$http.post(url, data)
  .then(function(data, Status) {
    console.log("booked Successfully!!!", Status);
    alert("Successfully booked!!");
  }, function(data, Status) {
    console.log("Error in booking!!", Status);
  });
}
}]);
