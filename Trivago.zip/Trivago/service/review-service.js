angular.module("hotelbooking").service('doreviewService', ['$http', function($http) {
  this.reviewService = function reviewService (selectedHotelreviews,reviewResponse) {
  var url = "http://localhost:8080/MVP/review/getAllReviews?hotelid=" + selectedHotelreviews + "";
  $http({
    method: 'GET',
    url: url
  }).then(function successCallback(response) {
    console.log("review success", response);
    reviewResponse(response);
  },function errorCallback(response) {
    console.log("Error", response);
  })
}
}]);
